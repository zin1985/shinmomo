# Shinmomo GitHub Commit Package 2026-04-26

このZIPは、新桃太郎伝説解析の今回スレッド成果物を、GitHubへコミットしやすいフォルダ構成にしたものです。

## 展開先

GitHubリポジトリ `zin1985/shinmomo` のルートに展開してください。

## 主な内容

- `handover/current_master.md`
  - 最新版の統合引継ぎ
- `handover/archive/shinmomo_thread_handover_20260426_final.md`
  - 同内容の履歴保存
- `data/npc_display/`
  - NPC表示、OAM、object linked list、animation、runtime解析
- `data/weapon_special/`
  - 武器特殊能力mini-script
- `data/text_trace/`
  - 会話テキスト採取Lua
- `data/runtime_hooks/`
  - BizHawk/Snes9x用runtime hook/polling Lua
- `data/experimental_patches/`
  - 実験IPSパッチ
- `data/manifests/manifest_all_20260426.csv`
  - 全同梱ファイル一覧

## コミットしないもの

ROM本体、ゲーム画面スクリーンショットは同梱していません。

```text
*.smc
image.png
```

## コマンド例

```bash
unzip shinmomo_github_commit_package_20260426.zip -d /path/to/shinmomo
cd /path/to/shinmomo

git add handover/current_master.md
git add handover/archive/shinmomo_thread_handover_20260426_final.md
git add data/

git commit -m "Update Shinmomo handover and analysis datasets 20260426"
git push
```

## 推奨

一括コミットでも問題ありませんが、履歴を分けるなら以下の2コミット推奨です。

1. `Update handover current master 20260426`
2. `Add NPC display, weapon special, and runtime trace data`
