MAIN_PAGE_NAME   = "Shin_Momotarou/main.html"

-- ==============================================================================================
-- INTERNAL VARIABLES FOR MISC USE
-- ==============================================================================================
dlgText = ""
tblUsed = 3 --Keeps the code number for the table being used (3: hiragana, kanji, roman. 4: katakana)

-- ==============================================================================================
-- EXTRA DEBUG / TRACE CONFIG
-- ==============================================================================================
ENABLE_DEV_PANEL        = true   -- write trace text into the HTML dev panel
TRACE_LINE_ID           = true   -- trace when PC_84A0C6 runs
TRACE_EVERY_CHAR        = false  -- very noisy; turn on only when needed
TRACE_LINE_END          = true   -- trace when PC_84B5E3 runs
TRACE_RAM_WINDOWS       = true   -- dump memory windows below on trace points
TRACE_MESSAGEAREA_ECHO  = false  -- if true, append debug text into messagearea too
DEBUG_MAX_LINES         = 120    -- ring buffer size for debug panel

RAM_WINDOWS = {
	{ name = "dlg",    base = 0x12A0, size = 0x20 },
	{ name = "stream", base = 0x1180, size = 0x20 },
}

_debugLines = {}


-- ==============================================================================================
-- HTML / TRACE HELPERS
-- ==============================================================================================
function htmlEscape(s)
	if s == nil then
		return ""
	end
	s = tostring(s)
	s = string.gsub(s, "&", "&amp;")
	s = string.gsub(s, "<", "&lt;")
	s = string.gsub(s, ">", "&gt;")
	return s
end

function toHex(v, digits)
	local fmt = "%0" .. tostring(digits or 2) .. "X"
	return string.format(fmt, v or 0)
end

function dumpMemoryWindow(base, size)
	local parts = {}
	for i = 0, size - 1 do
		local b = getMemory(base + i, 1)
		table.insert(parts, toHex(b, 2))
	end
	return table.concat(parts, " ")
end

function pushDebugLine(msg)
	table.insert(_debugLines, msg)
	while #_debugLines > DEBUG_MAX_LINES do
		table.remove(_debugLines, 1)
	end

	if ENABLE_DEV_PANEL then
		local joined = table.concat(_debugLines, "<br>")
		writeHTML("devarea", "<pre style='white-space:pre-wrap; font-size:0.9em;'>" .. joined .. "</pre>")
	end

	if TRACE_MESSAGEAREA_ECHO then
		writeHTML("messagearea", htmlEscape(msg))
	end
end

function traceState(tag, extraText)
	local lineID   = getMemory(0x12B4, 2)
	local chr      = getMemory(0x12B2, 2)
	local brk      = getMemory(0x12AD, 1)
	local tblFlag  = getMemory(0x12A9, 1)
	local tblName  = "?"
	if tblFlag == 0x00 then
		tblName = "tbl3"
	elseif tblFlag == 0x01 then
		tblName = "tbl4"
	end

	local msg = "[" .. tag .. "] "
		.. "line=$" .. toHex(lineID, 4)
		.. " chr=$" .. toHex(chr, 4)
		.. " br=" .. tostring(brk)
		.. " tbl=" .. tblName

	if extraText ~= nil and extraText ~= "" then
		msg = msg .. " | " .. htmlEscape(extraText)
	end

	pushDebugLine(msg)

	if TRACE_RAM_WINDOWS then
		for _, win in ipairs(RAM_WINDOWS) do
			pushDebugLine("  " .. win.name .. "[$" .. toHex(win.base, 4) .. "] " .. dumpMemoryWindow(win.base, win.size))
		end
	end
end


-- ==============================================================================================
-- This runs once before doLogic ever runs
-- ==============================================================================================
function init()
	resize(600, 450)
	loadHTML(MAIN_PAGE_NAME)
	callJSFunction("clearAllData")
	dlgText = ""
	tblUsed = 3
	_debugLines = {}
	if ENABLE_DEV_PANEL then
		writeHTML("devarea", "")
	end
end


-- ==============================================================================================
-- This handles messages sent by the emulator, like if the player presses certain buttons or
-- other events happen within the emulator itself
-- ==============================================================================================
function getMessage(str)
	if str == "resetgame" then
		init()
	elseif str == "loadstate" then
		init()
	end
end


-- ==============================================================================================
-- All main logic goes in here & gets called once per CPU cycle
-- ==============================================================================================
function doLogic()

end


-- ==================================================================================================
-- MAIN LOGIC (SCRIPT DISPLAYING, ETC.)
-- ==================================================================================================

function charCodeToCharacter(chr)
	local res = ""
	if tblUsed == 3 then --use hiragana table
		res = momo_3tbl[chr]
	elseif tblUsed == 4 then --use katakana table
		res = momo_4tbl[chr]
	end
	if res == nil then
		res = "⟨" .. tostring(chr) .. "⟩"
	end
	return res
end


--This function captures when a dialog is going to be printed, and dumps its lineID to the browser
--(that is, if I've identified correctly where the lineID is in memory)
function PC_84A0C6()
	local lineID = getMemory(0x12B4, 2)
	writeHTML("devinfo", "ID: " .. lineID)
	if TRACE_LINE_ID then
		traceState("PC_84A0C6", "line start")
	end
end


--84A1F3
--84A5BF this one can also be used, but causes some slowdowns while opening the menu
function PC_84A1F3()
	--We look if we get the value 3 or 4 to switch the table used accordingly. 0x12A9
	--has value 00 if hiragana is printed, and 01 if we print katakana.
	if getMemory(0x12A9, 1) == 0x0 then
		tblUsed = 3 --we use the hiragana/kanji/romaji table
	elseif getMemory(0x12A9, 1) == 0x1 then
		tblUsed = 4 --we use the katakana table
	end

	if getMemory(0x12AD, 1) == 0x1 then
		dlgText = dlgText .. "<br>" --line break, so everything isn't printed in a single line
		if TRACE_EVERY_CHAR then
			traceState("PC_84A1F3", "line break")
		end
	else
		local rawCode = string.format("%x", getMemory(0x12B2, 2))
		local charac = charCodeToCharacter(rawCode)
		dlgText = dlgText .. charac
		writeHTML("messagearea", dlgText)
		if TRACE_EVERY_CHAR then
			traceState("PC_84A1F3", "char=" .. charac .. " raw=$" .. string.upper(rawCode))
		end
	end
end


--This function dumps the current line to the log. Also cleans the dlgText variable
-- so the captured text lines don't keep being accumulated
function PC_84B5E3()
	if TRACE_LINE_END then
		traceState("PC_84B5E3", "flush text=" .. dlgText)
	end
	callJSFunction("copyToLog")
	dlgText = ""
	tblUsed = 3 --this is to avoid trying to read kanji (only in tbl 3) if some dialog leaves this var in 4 (katakana)
end


-- ==================================================================================================
-- TABLE FILES
-- ==================================================================================================
-- IMPORTANT:
-- Keep your existing momo_3tbl / momo_4tbl definitions below this line unchanged.
-- I am not duplicating the whole table block here because it is already present in your original main.lua.
