# 0x089220..0x0892D5 / 0x087BF5..0x087E53 行単位 address→台詞表

## 0x089220..0x0892D5

- `0x089220..0x089234`
  - raw: `評??会(ひんぴょう??かい)を するゎ`
  - inferred: 「品評会(ひんぴょうかい)を するわ」候補
  - confidence: 高

- `0x089235..0x08925C`
  - raw: `??コンテスト????場です!」「??おつれさまのぇわ??んちゃんもゎ??「⟨19⟩`
  - inferred: 「ここは コンテスト会場です！」候補
  - confidence: 高

- `0x08925D..0x089268`
  - raw: `されてみてぅいぞかが⟨1B⟩`
  - inferred: 「参加されてみて いかが…」候補
  - confidence: 中

- `0x089269..0x08926D`
  - raw: `か?⟨1E⟩??`
  - inferred: 前行末尾（…いかが？）候補
  - confidence: 中

- `0x08926E..0x089284`
  - raw: `歳??風ぶり太船Kさん⟨26⟩よみかた??がゎ`
  - inferred: 「突風ぶり太夫さん … 読み方が…」候補
  - confidence: 中

- `0x089285..0x08929C`
  - raw: `わからないっ??て? せいぅとっげぷうゎ⟨10⟩へぅ⟨4C⟩`
  - inferred: 「…わからないって？」候補
  - confidence: 中

- `0x08929D..0x0892BD`
  - raw: `だい??ゆう1だ⟨1D⟩⟨21⟩し??んぱん ひとすじ?? 40年ょ有〜P`
  - inferred: 「…しんぱん ひとすじ 40年…」候補
  - confidence: 高

- `0x0892BE..0x0892D5`
  - raw: `な 人なんだ⟨37⟩。ゎ知…と はゎずかしいよ`
  - inferred: 「…有名な人なんだ。知らないと はずかしいよ」候補
  - confidence: 高

## 0x087BF5..0x087E53

- `0x087BF5..0x087C13`
  - raw: `??「⟨02A0⟩さんも し??けん うけてみ??てよー! きっと〜ゎ`
  - inferred: 「桃太郎さんも しけん うけてみてよー! きっと…」候補
  - confidence: 中

- `0x087C14..0x087C24`
  - raw: `高い点 と??るんだろな」??`
  - inferred: 「高い点 とるんだろうな」候補
  - confidence: 中

- `0x087C25..0x087C32`
  - raw: `??だれがゃ字なばんかゎ`
  - inferred: 「だれが いちばんか…」候補
  - confidence: 低

- `0x087C33..0x087C39`
  - raw: `作った⟨11⟩⟨37⟩`
  - inferred: 前行続き（…作った/決めた）候補
  - confidence: 低

- `0x087C3A..0x087C49`
  - raw: `⟨10⟩ゎぜん⟨32⟩ おぼょえらんない`
  - inferred: 説明断片（未解決多）
  - confidence: 低

- `0x087C4A..0x087C53`
  - raw: `⟨17⟩⟨12⟩ぁゅは いつゎ`
  - inferred: 説明断片（未解決多）
  - confidence: 低

- `0x087C54..0x087C65`
  - raw: `べんきびょうってるの?」ぽ「⟨4A⟩`
  - inferred: 「…べんきょう してるの？」候補
  - confidence: 低

- `0x087C66..0x087C6D`
  - raw: `ぉボク??⟨48⟩`
  - inferred: 短い応答断片
  - confidence: 低

- `0x087C6E..0x087CBE`
  - raw: `ばんごはんを)ゎ食べたら⟨4D⟩⟨40⟩ゎ⟨2F⟩3⟨10⟩⟨11⟩ ⟨39⟩⟨0291⟩でしょ⟨3F⟩⟨16⟩ゃ⟨12⟩の けっかは〜⟨30⟩ぶ あのかべに〜ゎはりだされるよW⟨40⟩もちろょ⟨12⟩100⟨2F⟩⟨0C⟩ぬ⟨13⟩ね7鬼たいずじ ⟨22⟩`
  - inferred: 「ばんごはんを 食べたら… あの かべに はりだされるよ…」候補
  - confidence: 中

- `0x087CBF..0x087CC7`
  - raw: `てゎかしこんく⟨3C⟩`
  - inferred: 説明断片
  - confidence: 低

- `0x087CC8..0x087CD2`
  - raw: `と でき⟨3C⟩もずんね⟨16⟩`
  - inferred: 説明断片
  - confidence: 低

- `0x087CD3..0x087CDD`
  - raw: `ふオッパホン⟨02⟩`
  - inferred: 短い断片
  - confidence: 低

- `0x087CDE..0x087CF4`
  - raw: `ほ⟨2F⟩⟨10⟩おぬ+し…⟨1E⟩⟨20⟩??』⟨11⟩Lうけぁていくか??`
  - inferred: 説明断片
  - confidence: 低

- `0x087CF5..0x087D05`
  - raw: `·??⟨41⟩<W??AちしきLためし⟨25⟩??`
  - inferred: 「知識ためし…」候補
  - confidence: 中

- `0x087D06..0x087D0D`
  - raw: `できお⟨10⟩⟨4A⟩で…`
  - inferred: 短い断片
  - confidence: 低

- `0x087D0E..0x087D3D`
  - raw: `等??がよい<-⟨20⟩よろし⟨2D⟩⟨3C⟩ぉ⟨21⟩のM⟨16⟩を⟨26⟩しゅかめさせぎもらう+ぞ⟨0E⟩ぅ??ぇ⟨30⟩??を数8お⟨0A⟩を`
  - inferred: 説明断片（受験/確認/数/採点系）
  - confidence: 低

- `0x087D3E..0x087D53`
  - raw: `じゃ??…うがゅびー??マサカ⟨2E⟩ゥ⟨10⟩ァハシ`
  - inferred: 短い断片
  - confidence: 低

- `0x087D54..0x087D66`
  - raw: `ったく⟨4B⟩Y??⟨20⟩が よめば。P⟨37⟩ぁ??`
  - inferred: 短い断片
  - confidence: 低

- `0x087D67..0x087D74`
  - raw: `心な痛んくだぅぷたね`
  - inferred: 短い断片
  - confidence: 低

- `0x087D75..0x087D7F`
  - raw: `1問⟨13⟩そ。A⟨4B⟩??⟨4D⟩`
  - inferred: 「1問…」候補
  - confidence: 低

- `0x087D80..0x087D8F`
  - raw: `ょきたぇえんとなん⟨10⟩⟨17⟩ひく⟨2D⟩⟨2B⟩`
  - inferred: 短い断片
  - confidence: 低

- `0x087D90..0x087DB3`
  - raw: `Z -のーたこ??どもた??⟨10⟩手本びに ⟨4B⟩なってくれむよ。あまあ⟨22⟩-`
  - inferred: 説明断片
  - confidence: 低

- `0x087DB4..0x087DB6`
  - raw: `??⟨4B⟩`
  - inferred: 短い断片
  - confidence: 低

- `0x087DB7..0x087DC4`
  - raw: `ださら⟨0D⟩たかゃ⟨20⟩を⟨4B⟩ぬね?`
  - inferred: 短い断片
  - confidence: 低

- `0x087DC5..0x087DD5`
  - raw: `ん-。あなか⟨4A⟩⟨3C⟩⟨26⟩⟨24⟩ぞ だむ`
  - inferred: 短い断片
  - confidence: 低

- `0x087DD6..0x087DDA`
  - raw: `Qらな??`
  - inferred: 短い断片
  - confidence: 低

- `0x087DDB..0x087DE1`
  - raw: `から⟨37⟩つね⟨2E⟩`
  - inferred: 短い断片
  - confidence: 低

- `0x087DE2..0x087E24`
  - raw: `??80cなとれ??⟨20⟩⟨02FF⟩鬼たいじを め??ざす、D このくら??い⟨07⟩M⟨10⟩⟨37⟩とらなき⟨3D⟩⟨27⟩⟨09⟩⟨17⟩あっぱれぜちをいぷと そのぱ⟨20⟩!ぺあれば⟨37⟩`
  - inferred: 「…鬼たいじを めざす… このくらい… とらなきゃ…」候補
  - confidence: 中

- `0x087E25..0x087E53`
  - raw: `⟨4B⟩らずろ⟨0279⟩(できるぞ⟨1E⟩⟨25⟩も ??ちしき⟨36⟩⟨10⟩ためしじ。Pきけいつでもげ??れるがよい⟨1E⟩まだW`
  - inferred: 「…知識ためし… いつでも…」候補
  - confidence: 中
