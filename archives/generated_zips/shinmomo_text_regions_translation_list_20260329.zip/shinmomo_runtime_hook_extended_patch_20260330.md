# 新桃 runtime hook 拡張案（文字 + 周辺RAMダンプ）

以下は、いまの `main.lua` をベースにして、**表示中の文字だけでなく周辺RAMも継続ダンプ**できるようにするための改造案です。

## 目的

- 表示文字コード `0x12B2` の生値を残す
- lineID `0x12B4` を本文と一緒に残す
- table切替 `0x12A9` と改行判定 `0x12AD` を残す
- 表示前後のRAM窓を残して、script reader / 圧縮句の手がかりにする
- 毎CPU cycleではなく、**文字表示時と行確定時だけ**ダンプして重さを抑える

## 追加用コード例

```lua
MAIN_PAGE_NAME   = "Shin_Momotarou/main.html"

dlgText = ""
tblUsed = 3

-- 追加: デバッグログ
dbgLog = ""
charCount = 0

function init()
    resize(600, 450)
    loadHTML(MAIN_PAGE_NAME)
    callJSFunction("clearAllData")
    dbgLog = ""
    charCount = 0
end

function getMessage(str)
    if str == "resetgame" then
        init()
    elseif str == "loadstate" then
        init()
    end
end

function doLogic()
    -- 毎cycleダンプは重いので、基本ここでは何もしない
end

function hex1(v)
    return string.format("%02X", v)
end

function hex2(v)
    return string.format("%04X", v)
end

function readRange(addr, size)
    local t = {}
    local i = 0
    while i < size do
        t[#t+1] = hex1(getMemory(addr + i, 1))
        i = i + 1
    end
    return table.concat(t, " ")
end

function appendDebugLine(s)
    dbgLog = dbgLog .. s .. "<br>"
    writeHTML("devinfo", dbgLog)
end

function charCodeToCharacter(chr)
    local res = ""
    if tblUsed == 3 then
        res = momo_3tbl[chr]
    elseif tblUsed == 4 then
        res = momo_4tbl[chr]
    end
    if res == nil then
        res = "⟨" .. chr .. "⟩"
    end
    return res
end

-- lineID を取るフック
function PC_84A0C6()
    local lineID = getMemory(0x12B4, 2)
    appendDebugLine(
        "[LINEID] id=" .. hex2(lineID) ..
        " tbl=" .. hex1(getMemory(0x12A9, 1)) ..
        " br=" .. hex1(getMemory(0x12AD, 1))
    )
end

-- 1文字表示フック
function PC_84A1F3()
    if getMemory(0x12A9, 1) == 0x0 then
        tblUsed = 3
    elseif getMemory(0x12A9, 1) == 0x1 then
        tblUsed = 4
    end

    local raw = getMemory(0x12B2, 2)
    local lineID = getMemory(0x12B4, 2)
    local isBreak = getMemory(0x12AD, 1)
    local chr = charCodeToCharacter(string.format("%x", raw))

    charCount = charCount + 1

    if isBreak == 0x1 then
        dlgText = dlgText .. "<br>"
    else
        dlgText = dlgText .. chr
        writeHTML("messagearea", dlgText)
    end

    appendDebugLine(
        "[CHAR] #" .. tostring(charCount) ..
        " line=" .. hex2(lineID) ..
        " tbl=" .. tostring(tblUsed) ..
        " raw=" .. hex2(raw) ..
        " br=" .. hex1(isBreak) ..
        " chr=" .. chr
    )
end

-- 1行確定フック
function PC_84B5E3()
    local lineID = getMemory(0x12B4, 2)

    -- 周辺RAM窓も一緒に記録
    local win12A0 = readRange(0x12A0, 0x20)
    local win1180 = readRange(0x1180, 0x20)

    appendDebugLine(
        "[FLUSH] line=" .. hex2(lineID) ..
        " text=" .. dlgText
    )
    appendDebugLine(
        "[RAM 12A0] " .. win12A0
    )
    appendDebugLine(
        "[RAM 1180] " .. win1180
    )

    callJSFunction("copyToLog")
    dlgText = ""
    tblUsed = 3
    charCount = 0
end
```

## この改造で取れるもの

### 文字ごとのログ
- `line=xxxx`
- `tbl=3/4`
- `raw=xxxx`
- `br=00/01`
- `chr=実際の文字`

### 行ごとのログ
- lineID
- 表示文字列
- `0x12A0..0x12BF`
- `0x1180..0x119F`

## なぜこの2窓か

### `0x12A0..0x12BF`
いま既に分かっている表示寄りRAMがここに集中しています。

- `0x12A9` table切替
- `0x12AD` 改行判定
- `0x12B2` 現在文字コード
- `0x12B4` lineID候補

### `0x1180..0x119F`
既存解析では、script / stream / slot 管理に近いRAMとして重要です。  
とくに `87:918D` 周辺の dispatch loop では、`$1184,X` / `$1194,X` を stream ptr として読んでいます。

## さらに攻めるなら

もしこのツールが **PC hook を追加定義できる** なら、次のフックも有力です。

- `PC_87918D`
  - dispatch loop 入口
- `PC_879CC2`
  - opcode `0x35` handler
- `PC_879B55`
  - stream ptr 進行処理

ただし、これらは表示フックより呼ばれる頻度が高く、ログ量が爆発しやすいです。  
まずは `84A1F3 / 84B5E3 / 84A0C6` の3本だけで回すのが安全です。

## 実運用のおすすめ

1. まず現状の `main.lua` に上の debug 版を差す
2. ED直前や金太郎村イベントでログを取る
3. lineID と本文を確定する
4. `0x1180..0x119F` の変化から script 側ポインタの動きを見る
5. その後で必要なら `PC_87918D` 系の deeper hook に進む
```

## 期待できること

- 本文と lineID の対応
- 表示文字コードの生値保存
- 表示中のRAM窓保存
- `0x41A10` 系 reader hunt の足掛かり

## 期待しすぎない方がよいこと

- これだけで全文 script dump が完成するわけではない
- `02xx` 圧縮句の辞書本体までは直接出ない可能性が高い
- deeper hook なしで opcode 流れ全部は追い切れない
