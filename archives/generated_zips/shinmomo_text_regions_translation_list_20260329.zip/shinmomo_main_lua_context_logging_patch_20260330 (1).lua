MAIN_PAGE_NAME   = "Shin_Momotarou/main.html"

-- ==============================================================================================
-- INTERNAL VARIABLES FOR MISC USE
-- ==============================================================================================
dlgText = ""
tblUsed = 3 -- 3: hiragana/kanji/roman, 4: katakana
currentLineID = 0
lastCharCode = 0
lastBreakFlag = 0
logSeq = 0
currentMarker = "UNSET"

-- tracing toggles
TRACE_LINE_ID = true
TRACE_LINE_END = true
TRACE_EVERY_CHAR = false
TRACE_WINDOW_A = true -- 0x12A0..0x12BF
TRACE_WINDOW_B = true -- 0x1180..0x119F

-- ==============================================================================================
-- HELPERS
-- ==============================================================================================

function replaceHtml(el, html)
	local oldEl = type(el) == "string" and document.getElementById(el) or el
	local newEl = oldEl:cloneNode(false)
	newEl.innerHTML = html
	oldEl.parentNode:replaceChild(newEl, oldEl)
	return newEl
end

function writeHTML(id, msg)
	replaceHtml(id, msg)
end

function htmlEscape(str)
	if str == nil then return "" end
	str = tostring(str)
	str = string.gsub(str, "&", "&amp;")
	str = string.gsub(str, "<", "&lt;")
	str = string.gsub(str, ">", "&gt;")
	return str
end

function safeHex(num, width)
	if num == nil then return "nil" end
	if width == nil then width = 2 end
	return string.format("%0" .. tostring(width) .. "X", num)
end

function readRangeHex(addrStart, addrEnd)
	local out = {}
	local idx = 1
	for a = addrStart, addrEnd do
		out[idx] = safeHex(getMemory(a, 1), 2)
		idx = idx + 1
	end
	return table.concat(out, " ")
end

function buildContextRecord(hookName, textValue)
	logSeq = logSeq + 1

	local lineId = getMemory(0x12B4, 2)
	currentLineID = lineId

	local tableFlag = getMemory(0x12A9, 1)
	local breakFlag = getMemory(0x12AD, 1)
	local charCode = getMemory(0x12B2, 2)

	lastBreakFlag = breakFlag
	lastCharCode = charCode

	local rec = {}
	rec[#rec+1] = "<div class='ctxlog' style='margin-bottom:10px;border-bottom:1px dotted #666;padding-bottom:8px;'>"
	rec[#rec+1] = "<b>SEQ</b>=" .. tostring(logSeq)
	rec[#rec+1] = " | <b>HOOK</b>=" .. htmlEscape(hookName)
	rec[#rec+1] = " | <b>MARKER</b>=" .. htmlEscape(currentMarker)
	rec[#rec+1] = " | <b>LINEID</b>=0x" .. safeHex(lineId, 4)
	rec[#rec+1] = " | <b>TBL</b>=" .. tostring(tblUsed)
	rec[#rec+1] = " | <b>12A9</b>=0x" .. safeHex(tableFlag, 2)
	rec[#rec+1] = " | <b>12AD</b>=0x" .. safeHex(breakFlag, 2)
	rec[#rec+1] = " | <b>12B2</b>=0x" .. safeHex(charCode, 4)
	rec[#rec+1] = "<br><b>TEXT</b>=" .. htmlEscape(textValue)

	if TRACE_WINDOW_A then
		rec[#rec+1] = "<br><b>RAM[12A0..12BF]</b>=" .. readRangeHex(0x12A0, 0x12BF)
	end
	if TRACE_WINDOW_B then
		rec[#rec+1] = "<br><b>RAM[1180..119F]</b>=" .. readRangeHex(0x1180, 0x119F)
	end
	rec[#rec+1] = "</div>"

	return table.concat(rec, "")
end

function appendStructuredRecord(hookName, textValue)
	local rec = buildContextRecord(hookName, textValue)
	writeHTML("messagearea", rec)
	callJSFunction("copyToLog")
end

function updateDevInfo(extra)
	local lineId = getMemory(0x12B4, 2)
	local charCode = getMemory(0x12B2, 2)
	local tableFlag = getMemory(0x12A9, 1)
	local breakFlag = getMemory(0x12AD, 1)

	local info = {}
	info[#info+1] = "SEQ: " .. tostring(logSeq)
	info[#info+1] = " | MARKER: " .. currentMarker
	info[#info+1] = " | LINEID: 0x" .. safeHex(lineId, 4)
	info[#info+1] = " | TBL: " .. tostring(tblUsed)
	info[#info+1] = " | 12A9: 0x" .. safeHex(tableFlag, 2)
	info[#info+1] = " | 12AD: 0x" .. safeHex(breakFlag, 2)
	info[#info+1] = " | 12B2: 0x" .. safeHex(charCode, 4)
	if extra ~= nil and extra ~= "" then
		info[#info+1] = " | " .. extra
	end

	writeHTML("devinfo", table.concat(info, ""))
end

-- ==============================================================================================
-- INIT / MESSAGE HANDLING
-- ==============================================================================================

function init()
	resize(600, 450)
	loadHTML(MAIN_PAGE_NAME)
	callJSFunction("clearAllData")
	dlgText = ""
	tblUsed = 3
	currentLineID = 0
	lastCharCode = 0
	lastBreakFlag = 0
	logSeq = 0
	currentMarker = "UNSET"
	updateDevInfo("init")
end

function getMessage(str)
	if str == "resetgame" then
		init()
	elseif str == "loadstate" then
		init()
	elseif str == "clearlog" then
		callJSFunction("clearAllData")
		dlgText = ""
		updateDevInfo("clearlog")
	elseif string.sub(str, 1, 7) == "marker:" then
		currentMarker = string.sub(str, 8)
		appendStructuredRecord("MARKER", "[marker set] " .. currentMarker)
		updateDevInfo("marker")
	end
end

function doLogic()
end

-- ==============================================================================================
-- TEXT DECODER
-- ==============================================================================================

function charCodeToCharacter(chr)
	local res = ""
	if tblUsed == 3 then
		res = momo_3tbl[chr]
	elseif tblUsed == 4 then
		res = momo_4tbl[chr]
	end
	if res == nil then
		res = "⟨" .. tostring(chr) .. "⟩"
	end
	return res
end

-- ==============================================================================================
-- RUNTIME HOOKS
-- ==============================================================================================

function PC_84A0C6()
	currentLineID = getMemory(0x12B4, 2)
	updateDevInfo("PC_84A0C6")
	if TRACE_LINE_ID then
		appendStructuredRecord("84A0C6", "[line id seen]")
	end
end

function PC_84A1F3()
	if getMemory(0x12A9, 1) == 0x0 then
		tblUsed = 3
	elseif getMemory(0x12A9, 1) == 0x1 then
		tblUsed = 4
	end

	lastBreakFlag = getMemory(0x12AD, 1)
	lastCharCode = getMemory(0x12B2, 2)

	if lastBreakFlag == 0x1 then
		dlgText = dlgText .. "<br>"
	else
		local charac = charCodeToCharacter(string.format("%x", lastCharCode))
		dlgText = dlgText .. charac
		writeHTML("messagearea", htmlEscape(dlgText))
	end

	updateDevInfo("PC_84A1F3")

	if TRACE_EVERY_CHAR then
		appendStructuredRecord("84A1F3", dlgText)
	end
end

function PC_84B5E3()
	updateDevInfo("PC_84B5E3")
	if TRACE_LINE_END then
		appendStructuredRecord("84B5E3", dlgText)
	else
		callJSFunction("copyToLog")
	end
	dlgText = ""
	tblUsed = 3
end

-- ==============================================================================================
-- TABLE FILES
-- KEEP THE ORIGINAL momo_3tbl / momo_4tbl DEFINITIONS BELOW THIS LINE
-- ==============================================================================================
