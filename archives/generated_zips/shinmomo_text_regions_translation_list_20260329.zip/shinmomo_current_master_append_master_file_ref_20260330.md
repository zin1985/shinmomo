## 正本ファイル参照（address→台詞 対応表）
後半イベント会話帯 `0x09B598..0x09B75A` の address→台詞 対応表の正本は、以下のファイルとする。

- Markdown 正本: `shinmomo_address_to_dialogue_9B598_9B75A_reintegrated_20260330.md`
- CSV 正本: `shinmomo_address_to_dialogue_9B598_9B75A_reintegrated_20260330.csv`

運用ルール:
- この帯の本文対応を更新した場合は、まず上記正本ファイルを更新し、その後 `current_master.md` 側は要約・認識変更・参照先更新のみ行う。
- `current_master.md` には全文を重複転記せず、要点と正本ファイル名のみ保持する。
- 旧版の個別差し替えファイル (`9B5C3_9B644` 単独版など) は作業中間物として扱い、最終判断は再統合版を優先する。
